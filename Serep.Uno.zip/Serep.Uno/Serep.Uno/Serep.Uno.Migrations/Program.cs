﻿using System;

namespace Serep.Uno.Migrations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
