﻿using Microsoft.Toolkit.Collections;
using Microsoft.Toolkit.Uwp.UI.Controls;
using Serep.Uno.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Data;

namespace Serep.Default
{
    public class RepTable
    {
        private ObservableCollection<Reports> Sourse { get; set; }
        public ObservableGroupedCollection<DateTime, Reports> groupedSource { get; private set; }

        public RepTable()
        {
            Sourse = new();
            using var db = new DBContext();

            var reports = db.reports.ToList();

            foreach (var report in reports)
            {
                report.PropertyChanged += EditDBEntry;
                Sourse.Add(report);
            }

            Sort();
        }
        public void Sort()
        {
            Sourse = new ObservableCollection<Reports>(from item in Sourse orderby item.Date descending select item);

            var grouped = Sourse.GroupBy(item => new DateTime(item.Date.Year, item.Date.Month, 1)).OrderBy(g => g.Key);
            groupedSource = new ObservableGroupedCollection<DateTime, Reports>(grouped);
            groupedSource = new ObservableGroupedCollection<DateTime, Reports>(from item in groupedSource orderby item.Key descending select item);
            var cvs = new CollectionViewSource
            {
                IsSourceGrouped = true,
                Source = groupedSource,
            };
        }
        public string Count(int year, int month)
        {
            int pub_count = 0;
            int vid_count = 0;
            TimeSpan time_count = new();
            int pp_count = 0;
            int std_count = 0;

            foreach (var rep in Sourse)
            {
                if (rep.Date.Year == year && rep.Date.Month == month)
                {
                    pub_count += rep.Publications;
                    vid_count += rep.Videos;
                    time_count += rep.Time;
                    pp_count += rep.Pp;
                    std_count += rep.Studys;
                }
            }

            return $"publications — {pub_count} videos — {vid_count} time — {time_count.ToString(@"hh\:mm")} pp — {pp_count} studys — {std_count}";
        }

        public void AddToDB(object obj)
        {
            using var db = new DBContext();
            var report = obj as Reports;

            db.Add(report);
            db.SaveChanges();
            Sourse.Add(report);
            report.PropertyChanged += EditDBEntry;
            Sort();
        }
        void EditDBEntry(object sender, PropertyChangedEventArgs e)
        {
            using var db = new DBContext();
            var d = sender as Reports;

            db.reports.Update(d);
            db.SaveChanges();
            Sort();
        }
        public void DeleteFromDB(object obj)
        {
            using var db = new DBContext();
            var report = obj as Reports;

            db.Remove(report);
            db.SaveChanges();
            Sourse.Remove(report);
        }
    }

    public class Timer
    {
        private DispatcherTimer dispatcherTimer;
        private DateTimeOffset timerStart;
        private DateTimeOffset timerPause;
        private TimeSpan pausedTime;
        public TimeSpan timer { get; private set; }
        public Visibility start { get; private set; }
        public Visibility stop { get; private set; }
        public Visibility pause { get; private set; }
        public Visibility _continue { get; private set; }
        public Visibility addToReport { get; private set; }

        public Timer()
        {
            dispatcherTimer = new DispatcherTimer();
            dispatcherTimer.Tick += dispatcherTimer_Tick;
            dispatcherTimer.Interval = new TimeSpan(0, 0, 1);
            start = Visibility.Visible;
            stop = Visibility.Collapsed;
            pause = Visibility.Collapsed;
            _continue = Visibility.Collapsed;
            addToReport = Visibility.Collapsed;
        }
        public void dispatcherTimer_Tick(object sender, object e)
        {
            timer = DateTimeOffset.Now - timerStart - pausedTime;
        }

        public void TimerStart(object obj)
        {
            dispatcherTimer.Start();
            timer = new();
            timerStart = DateTimeOffset.Now;
            start = Visibility.Collapsed;
            stop = Visibility.Visible;
            pause = Visibility.Visible;
            _continue = Visibility.Collapsed;
            addToReport = Visibility.Collapsed;
        }
        public void TimerStop(object obj)
        {
            dispatcherTimer.Stop();
            start = Visibility.Visible;
            stop = Visibility.Collapsed;
            pause = Visibility.Collapsed;
            _continue = Visibility.Collapsed;
            addToReport = Visibility.Visible;
        }
        public void TimerPause(object obj)
        {
            dispatcherTimer.Stop();
            timerPause = DateTimeOffset.Now;
            start = Visibility.Collapsed;
            stop = Visibility.Visible;
            pause = Visibility.Collapsed;
            _continue = Visibility.Visible;
            addToReport = Visibility.Collapsed;
        }
        public void TimerContinue(object obj)
        {
            dispatcherTimer.Start();
            pausedTime += DateTimeOffset.Now - timerPause;
            start = Visibility.Collapsed;
            stop = Visibility.Visible;
            pause = Visibility.Visible;
            _continue = Visibility.Collapsed;
            addToReport = Visibility.Collapsed;
        }
        public void TimerAdd()
        {
            if (timer.Seconds >= 30) { timer += new TimeSpan(0, 0, 60 - timer.Seconds); }
            else { timer -= new TimeSpan(0, 0, timer.Seconds); }
            timer = new();
            addToReport = Visibility.Collapsed;
        }
    }
}
