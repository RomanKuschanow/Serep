﻿using ColorCode.Compilation.Languages;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Toolkit.Collections;
using Microsoft.Toolkit.Uwp.UI.Controls;
using Serep.Uno;
using Serep.Uno.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Windows.Input;
using System.Xml.Linq;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Serep.Uno
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
{
        public Default.RepTable Data { get; set; }
        public Default.Timer Timer { get; set; }
        public ViewModel viewModel { get; set; }

        public MainPage()
        {
            this.InitializeComponent();
            ApplicationView.PreferredLaunchViewSize = new Size(800, 500);
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;
            Data = new();
            Timer = new();
            viewModel = new(Data, Timer);
            var cvs = new CollectionViewSource
            {
                IsSourceGrouped = true,
                Source = Data.groupedSource,
            };
            dataGrid.ItemsSource = cvs.View;
        }

        private void LoadingRowGroup(object sender, DataGridRowGroupHeaderEventArgs e)
        {
            ICollectionViewGroup group = e.RowGroupHeader.CollectionViewGroup;
            Reports item = group.GroupItems[0] as Reports;
            e.RowGroupHeader.PropertyValue = $"{item.Date.Year}.{item.Date.Month} total count: {Data.Count(item.Date.Year, item.Date.Month)}";
        }
        private void TimeChanged(object sender, TimePickerValueChangedEventArgs e)
        {
            if (add != null)
            {
                if (time.Time.TotalMinutes > 0)
                    add.IsEnabled = true;
                else
                    add.IsEnabled = false;
            }
        }

        private void TimerAdd(object sender, RoutedEventArgs e)
        {
            Timer.TimerAdd();
            time.Time = Timer.timer;
        }
    }

    public class ViewModel : INotifyPropertyChanged
    {
        public Default.RepTable Data { get; set; }
        public Default.Timer Timer { get; set; }

        public ViewModel(Default.RepTable data, Default.Timer timer)
        {
            Data = data;
            Timer = timer;
        }

        #region //это поле пойдет как аргумент при создании записи в базу
        private Reports report { get; set; }
        public Reports Report { get => report; set => report = value; }
        #endregion

        #region //эти поля привязаны к элементам создания отчета с модом TowWay
        private int publications;
        public int Publications { get => publications; set { publications = value; ChangeRerort(); } }

        private int videos;
        public int Videos { get => videos; set { videos = value; ChangeRerort(); } }

        private TimeSpan time;
        public TimeSpan Time { get => time; set { time = value; ChangeRerort(); } }

        private int pp;
        public int Pp { get => pp; set { pp = value; ChangeRerort(); } }

        private int studys;
        public int Studys { get => studys; set { studys = value; ChangeRerort(); } }

        private string note = "";
        public string Note { get => note; set { note = value; ChangeRerort(); } }
        #endregion


        private void ChangeRerort()
        {
            Report = new Reports
            {
                Date = DateTimeOffset.Now,
                Publications = Publications,
                Videos = Videos,
                Time = Time,
                Pp = Pp,
                Studys = Studys,
                Note = Note
            };
        }


        public ICommand AddReport { get => new RelayCommand(Data.AddToDB); }
        public ICommand DeleteReport { get => new RelayCommand(Data.DeleteFromDB); }
        public ICommand TimerStart { get => new RelayCommand(Timer.TimerStart); }
        public ICommand TimerStop { get => new RelayCommand(Timer.TimerStop); }
        public ICommand TimerPause { get => new RelayCommand(Timer.TimerPause); }
        public ICommand TimerContinue { get => new RelayCommand(Timer.TimerContinue); }


        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        internal void OnPropertyChanged([CallerMemberName] string propName = "") =>
         PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        #endregion
    }
    public class RelayCommand : ICommand
    {
        private readonly Predicate<object> _canExecute;
        private readonly Action<object> _execute;
        public event EventHandler CanExecuteChanged;
        public RelayCommand(Action<object> execute) : this(execute, null) { }
        public RelayCommand(Action<object> execute, Predicate<object> canExecute) { _execute = execute; _canExecute = canExecute; }
        public bool CanExecute(object parameter) => (_canExecute == null) ? true : _canExecute(parameter);
        public void Execute(object parameter) => _execute(parameter);
        public void RaiseCanExecuteChanged() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
    }

    public class DateFormatConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, string language)
        {
            if (value == null)
                return null;

            DateTime dt = DateTime.Parse(value.ToString());
            return dt.ToString("yyyy.MM.dd");
        }

        public object ConvertBack(object value, Type targetType, object parameter, string language)
        {
            throw new NotImplementedException();
        }
    }
    public class TimeFormatConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, string language)
        {
            if (value == null)
                return null;

            TimeSpan t = TimeSpan.Parse(value.ToString());
            return t.ToString(@"hh\:mm");
        }

        public object ConvertBack(object value, Type targetType, object parameter, string language)
        {
            throw new NotImplementedException();
        }
    }
}
